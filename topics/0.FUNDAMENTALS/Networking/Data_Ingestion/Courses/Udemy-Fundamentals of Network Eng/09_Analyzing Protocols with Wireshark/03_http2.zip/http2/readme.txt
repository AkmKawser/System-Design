In this video I learned how to decrypt TLS traffic with Wireshark so we can look at the traffic. Then took a look at how HTTP/2 streams are formed. The Magic HTTP/2 Stream is for sure interesting and the odd stream Ids are too!

HTTP/2 RFC

https://tools.ietf.org/html/rfc7540#section-3.5

https://http2.github.io/http2-spec/#SETTINGS_MAX_CONCURRENT_STREAMS

Connection Preface

HTTP/2 connections are opened with the preface '0x505249202a20485454502f322e300d0a0d0a534d0d0a0d0a', or "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n". The preface is designed to avoid the processing of frames by servers and intermediaries which support earlier versions of HTTP but not 2.0.

connection preface

Note: The client connection preface is selected so that a large

proportion of HTTP/1.1 or HTTP/1.0 servers and intermediaries do

not attempt to process further frames. Note that this does not

address the concerns raised in [TALKING].

export SSLKEYLOGFILE=/Users/HusseinNasser/tempkeys/key

:30 protocol ossifcations

13-30 http smuggling

From RFC (we discovered this in the video)

5.1.1 Stream Identifiers

Streams are identified with an unsigned 31-bit integer. Streams initiated by a client MUST use odd-numbered stream identifiers; those initiated by the server MUST use even-numbered stream identifiers. A stream identifier of zero (0x0) is used for connection control messages; the stream identifier of zero cannot be used to establish a new stream.


